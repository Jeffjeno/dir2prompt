"""dir2prompt - 目录树生成工具"""

__version__ = "0.1.0"
__author__ = "WangZhiZhou"
__email__ = "wangzhizhou@example.com"

from .main import DirectoryTreeGenerator, main

__all__ = ["DirectoryTreeGenerator", "main"]